package com.mycompany.myapp.dao;

import org.springframework.stereotype.Component;

@Component
public interface Exam10Dao {

	public void insert();

	public void select();
}
