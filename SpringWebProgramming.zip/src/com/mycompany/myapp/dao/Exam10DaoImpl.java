package com.mycompany.myapp.dao;

import org.springframework.stereotype.Component;

@Component
public class Exam10DaoImpl implements Exam10Dao {

	public void insert() {
		System.out.println("insert() 호출");
	}

	public void select() {
		System.out.println("select() 호출");
	}
}
